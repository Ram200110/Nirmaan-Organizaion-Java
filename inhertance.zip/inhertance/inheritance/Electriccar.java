package inheritance;

public class Electriccar extends Car{
public void chargeBattery() {
	System.out.println("Electric car is chargeing");
}
}
