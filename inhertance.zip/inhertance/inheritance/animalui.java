package inheritance;

public class animalui {
	public static void main(String[] args) {
		
		animal a = new animal();
		a.makeSound();
		dog d= new dog();
		d.makeSound();
		cat c = new cat();
		c.makeSond();
		
	}



}
