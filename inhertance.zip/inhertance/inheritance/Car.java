package inheritance;

public class Car extends vehicle{
public void drive() {
	System.out.println("car is driving...");
}
}
