package inheritance;

public class animal {
public void makeSound() {
	System.out.println("This animal makes a sound");
}
}
