package inheritance;

public class cycleui {
	public static void main(String[] args) {
		cycle cy = new cycle();
		cy.chain();
		cy.startEngine();
	}

}
