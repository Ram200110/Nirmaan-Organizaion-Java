package inheritance;

public class cycle extends vehicle{
	public void chain() {
		System.out.println("chain oil..");
	}

}
