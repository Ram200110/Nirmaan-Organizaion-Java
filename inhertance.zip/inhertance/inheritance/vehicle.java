package inheritance;

public class vehicle {
public void startEngine() {
	System.out.println("Vehicle engine started..");
}
}


