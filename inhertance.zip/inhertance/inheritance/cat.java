package inheritance;

public class cat extends animal {
public void makeSond() {
	System.out.println("The cat meows..");
}
}
