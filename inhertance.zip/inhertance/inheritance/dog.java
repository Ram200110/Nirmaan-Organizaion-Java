package inheritance;

public class dog extends animal {
	 public void makeSound(){
	System.out.println("The dog barks..");
}
}
