package inheritance;

public class Bike extends vehicle{
public void kickstart() {
	System.out.println("Bike 's kick- started..");
}
}
